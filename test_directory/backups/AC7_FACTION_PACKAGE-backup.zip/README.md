# AC7 FACTION IFF

Self-contained briefing page — all images are embedded, no build step.

## Run
    npm install
    npm start
Serves on http://localhost:8080 and opens the page.

## No-node fallback
    python -m http.server 8080
Then open http://localhost:8080/index.html — or just double-click `index.html`; it needs no server at all.

## Contents
- `index.html` / `AC7_FACTION_IFF.html` — the page (identical copies)
- `flags/` `images/` `maps/` — source assets, already embedded in the HTML
